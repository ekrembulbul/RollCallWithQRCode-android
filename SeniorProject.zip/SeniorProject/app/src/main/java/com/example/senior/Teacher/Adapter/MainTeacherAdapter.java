package com.example.senior.Teacher.Adapter;

public class MainTeacherAdapter extends RecyclerView.Adapter<MainTeacherAdapter.MyViewHolder> {
}
